import Localbase from 'localbase';
export const db = new Localbase('pwaPosReact')
