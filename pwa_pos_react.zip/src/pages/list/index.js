import { faTrash } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import React from "react";
import NumberFormat from "react-number-format";
import { toast } from "react-toastify";
import { Button, ButtonGroup, Table } from "reactstrap";
import CustomModal from "../../components/CustomModal";
import { db } from '../../DBConfig';
import ToastError from "../../services/request/ErrorReq";
import SalesAPI from "../../services/request/Sales";
import "./index.css";
let _ = require('lodash');

class List extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: [],
    };
  }

  deleteSales = (id) => {
    
    db.collection('tbl_sales').doc({ sales_id: id }).delete()
      .then(response => {
        
        db.collection('tbl_sales_item').doc({ sales_id: id }).delete()
        .then(response => {

          toast.success("Sales Delete Successfully");

          if(navigator.onLine){
            SalesAPI.salesDelete({ sales_id: id })
            .then((result) => {               
              this.refreshSales();
            })
            .catch((err) => {
              console.log('Error Sales Delete Server ')
            });
          }else{
            this.refreshSales();
          }
          

        })
        .catch(error => {
          console.log('Error Sales Delete Local from  tbl_sales_item')
        })

      })
      .catch(error => {
        console.log('Error Sales Delete Local from  tbl_sales')
      })

     

    
  };

  componentDidMount() {
    this.refreshSales();
  }

  refreshSales() {
    SalesAPI.salesList()
      .then((result) => {
        /*
        * SalesAPI insert With IndexDB [START]
        */
          SalesAPI.salesList()
          .then((result) => {
            let data = result.data.data;
            let raw_data = result.data.raw_data;
 
            db.collection('tbl_sales').doc({ _sync: 1 }).delete();
            db.collection('tbl_sales_item').doc({ _sync: 1 }).delete();     

            _.forEach(data, function(value, key) {  
                db.collection('tbl_sales').add({
                  id          : value.customer_id,
                  name        : value.customer_name,
                  discount    : value.discount,
                  date        : value.sales_date,
                  sales_id    : value.sales_id,
                  total       : value.total,
                  _sync       : 1
                }) 
            });

            _.forEach(raw_data, function(value, key) {  
              let _total = value.item_price * value.item_qty;
              db.collection('tbl_sales_item').add({
                sales_id      : value._id,
                item_id       : value.item_id,
                item_name     : value.item_name,
                item_price    : value.item_price,
                item_qty      : value.item_qty,
                item_subtotal : _total,
                _sync         : 1
              }) 
          });


          })
          .catch((err) => {
            console.log('SalesAPI IndexedDB',err)
          });
        /*  
        * SalesAPI insert With IndexDB [START]
        */

        this.setState({
          list: result.data.data,
        });
      })
      .catch((err) => {
        /*
        * Data Generate With IndexDB [START]
        */
        db.collection('tbl_sales').get().then(item => {           
          let salesList = [];
          _.forEach(item, function(value, key) {              
            salesList.push({
              customer_id   : value.id,
              customer_name : value.name,
              discount      : value.discount,
              sales_date    : value.date,
              sales_id      : value.sales_id,
              total         : value.total,
            })           
          });
          this.setState({
            list: salesList             
          });
        }) 

        /*
        * Data Generate With IndexDB [END]
        */
        ToastError(err);
      });
  }
  render() {
    const SalesList = this.state.list;
    return (
      <CustomModal title="Sales">
        <Table responsive hover borderless>
          <thead className="table-active">
            <tr>
              <th>#</th>
              <th>Sales Date</th>
              <th>Customer</th>
              <th>Discount</th>
              <th>Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {SalesList.map((obj, index) => {
              return (
                <tr key={index.toString()}>
                  <td>{index + 1}</td>
                  <td>{obj.sales_date}</td>
                  <td>{obj.customer_name}</td>
                  <td>
                    <NumberFormat
                      value={obj.discount}
                      displayType={"text"}
                      thousandSeparator={true}
                    />
                  </td>
                  <td>
                    <NumberFormat
                      value={parseFloat(obj.total)}
                      displayType={"text"}
                      thousandSeparator={true}
                    />
                  </td>
                  <td className="text-center">
                    <ButtonGroup size="sm">
                      <Button
                        title="Delete Sales"
                        onClick={() => {
                          this.deleteSales(obj.sales_id);
                        }}
                        color="danger"
                      >
                        <FontAwesomeIcon icon={faTrash} /> Delete
                      </Button>
                    </ButtonGroup>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </Table>
      </CustomModal>
    );
  }
}

export default List;
