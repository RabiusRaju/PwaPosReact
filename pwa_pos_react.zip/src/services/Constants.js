export const path_server = "http://localhost:8000";
export const request_delay = 300000;
